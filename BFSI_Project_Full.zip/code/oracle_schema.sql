
-- Oracle BFSI Schema

CREATE TABLE CUSTOMER (
    customer_id NUMBER PRIMARY KEY,
    name VARCHAR2(100),
    dob DATE,
    email VARCHAR2(150),
    phone VARCHAR2(20),
    created_at DATE DEFAULT SYSDATE
);

CREATE TABLE ACCOUNT (
    account_id NUMBER PRIMARY KEY,
    customer_id NUMBER REFERENCES CUSTOMER(customer_id),
    balance NUMBER,
    opened_at DATE
);

CREATE TABLE CORE_TRANSACTION (
    txn_id NUMBER PRIMARY KEY,
    account_id NUMBER REFERENCES ACCOUNT(account_id),
    txn_date DATE,
    amount NUMBER,
    txn_type VARCHAR2(20)
)
PARTITION BY RANGE (txn_date) (
    PARTITION p2024 VALUES LESS THAN (TO_DATE('2025-01-01','YYYY-MM-DD')),
    PARTITION p2025 VALUES LESS THAN (TO_DATE('2026-01-01','YYYY-MM-DD'))
);

CREATE TABLE CARD_TXN (
    card_txn_id NUMBER PRIMARY KEY,
    account_id NUMBER REFERENCES ACCOUNT(account_id),
    merchant_id NUMBER,
    txn_date DATE,
    amount NUMBER,
    is_fraud NUMBER(1)
);

CREATE TABLE MERCHANT (
    merchant_id NUMBER PRIMARY KEY,
    name VARCHAR2(100),
    category VARCHAR2(50)
);

CREATE TABLE LOAN (
    loan_id NUMBER PRIMARY KEY,
    customer_id NUMBER REFERENCES CUSTOMER(customer_id),
    amount NUMBER,
    issued_at DATE
);

CREATE TABLE LOAN_REPAYMENT (
    repayment_id NUMBER PRIMARY KEY,
    loan_id NUMBER REFERENCES LOAN(loan_id),
    repayment_date DATE,
    amount NUMBER
);

CREATE TABLE INSURANCE_POLICY (
    policy_id NUMBER PRIMARY KEY,
    customer_id NUMBER REFERENCES CUSTOMER(customer_id),
    policy_type VARCHAR2(50),
    premium NUMBER,
    issued_at DATE
);

CREATE TABLE CLAIM (
    claim_id NUMBER PRIMARY KEY,
    policy_id NUMBER REFERENCES INSURANCE_POLICY(policy_id),
    claim_date DATE,
    amount NUMBER,
    status VARCHAR2(20)
);

CREATE TABLE KYC_EVENT (
    event_id NUMBER PRIMARY KEY,
    customer_id NUMBER REFERENCES CUSTOMER(customer_id),
    event_type VARCHAR2(50),
    event_date DATE
);

CREATE TABLE AML_ALERT (
    alert_id NUMBER PRIMARY KEY,
    customer_id NUMBER REFERENCES CUSTOMER(customer_id),
    alert_date DATE,
    reason VARCHAR2(200),
    status VARCHAR2(20)
);

CREATE INDEX idx_core_txn_date ON CORE_TRANSACTION(txn_date);
