
import pandas as pd
import numpy as np
from faker import Faker
import random

fake = Faker()

def gen_customers(n=10000):
    data = []
    for i in range(1,n+1):
        data.append([i, fake.name(), fake.date_of_birth(minimum_age=18, maximum_age=70),
                     fake.email(), fake.phone_number()])
    return pd.DataFrame(data, columns=["customer_id","name","dob","email","phone"])

# Add similar functions for accounts, transactions, etc.
