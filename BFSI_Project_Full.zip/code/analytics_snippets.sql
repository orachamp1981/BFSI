
-- Fraud features
CREATE OR REPLACE VIEW V_CARD_FRAUD_FEATURES AS
SELECT c.card_txn_id,
       c.account_id,
       c.amount,
       CASE WHEN c.amount > 5000 THEN 1 ELSE 0 END AS high_amount_flag,
       CASE WHEN c.is_fraud = 1 THEN 1 ELSE 0 END AS label
FROM CARD_TXN c;

-- AML structuring heuristic
SELECT customer_id,
       COUNT(*) as txn_count,
       SUM(amount) as total_amount
FROM CORE_TRANSACTION
WHERE txn_type='CREDIT' AND amount BETWEEN 9000 AND 10000
GROUP BY customer_id
HAVING COUNT(*) >= 3;
