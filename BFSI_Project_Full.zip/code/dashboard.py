
import streamlit as st
import pandas as pd

st.title("BFSI KPI Dashboard")

customer = pd.read_csv("data/CUSTOMER.csv")
accounts = pd.read_csv("data/ACCOUNT.csv")
txn = pd.read_csv("data/CORE_TRANSACTION.csv")

st.metric("Total Customers", len(customer))
st.metric("Total Accounts", len(accounts))
st.metric("Transactions", len(txn))

st.line_chart(txn.groupby("txn_date").amount.sum())
