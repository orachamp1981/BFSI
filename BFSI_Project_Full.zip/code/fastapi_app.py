
from fastapi import FastAPI, HTTPException
import cx_Oracle

app = FastAPI(title="BFSI Oracle API")

dsn = cx_Oracle.makedsn("localhost", 1521, service_name="XE")
conn = cx_Oracle.connect(user="your_user", password="your_pass", dsn=dsn)

@app.get("/accounts/{id}/balance")
def get_balance(id: int):
    cur = conn.cursor()
    cur.execute("SELECT NVL(SUM(CASE WHEN txn_type='CREDIT' THEN amount ELSE -amount END),0) FROM CORE_TRANSACTION WHERE account_id=:id", [id])
    bal, = cur.fetchone()
    return {"account_id": id, "balance": bal}
