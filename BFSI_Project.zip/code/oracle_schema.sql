-- oracle schema placeholder
CREATE TABLE DUMMY (id NUMBER);