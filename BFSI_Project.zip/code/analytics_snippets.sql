-- analytics placeholder
SELECT 1 FROM DUAL;