# generator placeholder
print('generate data')