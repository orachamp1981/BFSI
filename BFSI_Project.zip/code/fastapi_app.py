# fastapi placeholder
print('fastapi')